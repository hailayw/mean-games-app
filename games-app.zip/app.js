// 1- This is an express server that listens to port 5353 that performs the following requirements 

//    a- serve the following files: index.html, page1.html, page2.html.
//    b- if the user makes a GET request without stating a file serve index.html
//    c- serve a JSON response if the request is a POST

// Submit your code or a link to your personal GitHub where you have your code exists.

// 3- Write an express application that returns the main page for the MEAN Games application.

const express = require('express');
const path = require('path');

require('dotenv').config();

const app = express();

//serves index.html
app.get('/', express.static(path.join(__dirname, 'public')));

//serves index.html, page1.html, page2.html
app.use(express.static(path.join(__dirname, 'public')));

const server = app.listen(process.env.PORT, ()=>{
    const port = server.address().port;
    console.log(process.env.MSG_SERVER_START, port);    
});
